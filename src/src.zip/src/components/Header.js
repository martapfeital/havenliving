import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./styles.css";

export function Header() {
    const [isMenuOpen, setIsMenuOpen] = useState(false); // Estado para o menu toggle

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen); // Alterna o estado do menu
    };

    return (
        <header>
            <div className="header">
                {/* Logo como botão funcional */}
                <NavLink to='/'>
                    <button className="logo-button">
                        <div className="logo"></div>
                    </button>
                </NavLink>

                {/* Navegação */}
                <nav className={`navigation ${isMenuOpen ? "active" : ""}`} id="nav-menu">
                    <NavLink to='/buy' className="nav-link">
                        Buy
                    </NavLink>
                    <NavLink to='/favorite' className="nav-link">
                        Favourites
                    </NavLink>
                    <NavLink to='/sell' className="nav-link">
                        <button className="sell-button">Sell</button>
                    </NavLink>
                </nav>

                {/* Botão Toggle */}
                <div className="menu-toggle" id="menu-toggle" onClick={toggleMenu}>
                    ☰
                </div>
            </div>
        </header>
    );
}
