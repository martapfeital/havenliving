import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import './styles.css';

export function Slider_(props) {
    const sliderSettings = {
        dots: true, // Exibe as bolinhas abaixo do slider
        arrows: true, // Exibe as setas de navegação
        infinite: true,
        speed: 500,
        slidesToShow: 3, // Quantas casas mostrar ao mesmo tempo
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    arrows: true,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    dots: true,
                    arrows: false, // Remove as setas em dispositivos menores
                },
            },
        ],
    };

    return (
        <Slider {...sliderSettings} className="custom-slider">
            {props.children}
        </Slider>
    );
}
