import React from "react";
import './styles.css';

export function Footer() {
    return (
        <div className="footer-wrapper">
            <footer className="footer-container">
                {/* Coluna de Contatos */}
                <div className="contact">
                    <h4>Contacts:</h4>
                    <p>
                        <img src="/icons/phone.png" alt="Phone" className="icon" />
                        912345678
                    </p>
                    <p>
                        <img src="/icons/email.png" alt="Email" className="icon" />
                        HavenLiving@email.com
                    </p>
                    <p>
                        <img src="/icons/location.png" alt="Location" className="icon" />
                        Lisbon, Portugal
                    </p>
                </div>

                {/* Coluna de Redes Sociais */}
                <div className="social-media">
                    <h4>Social Media:</h4>
                    <p>
                        <img src="/icons/instagram.png" className="icon" />
                        Instagram: HavenLiving
                    </p>
                    <p>
                        <img src="/icons/X.png" className="icon" />
                        Twitter: HavenLiving
                    </p>
                    <p>
                        <img src="/icons/facebook.png" className="icon" />
                        Facebook: HavenLiving
                    </p>
                    <p>
                        <img src="/icons/tiktok.png" className="icon" />
                        TikTok: HavenLiving
                    </p>
                </div>

                {/* Coluna de Links de Navegação */}
                <div className="links">
                    <h4>Navigation:</h4>
                    <ul>
                        <li>
                            <a href="#">Home Page</a>
                        </li>
                        <li>
                            <a href="http://localhost:3001/buy">Buy</a>
                        </li>
                        <li>
                            <a href="http://localhost:3001/favourite">Favourites</a>
                        </li>
                        <li>
                            <a href="http://localhost:3001/sell">Sell</a>
                        </li>
                    </ul>
                </div>

                {/* Nota no Rodapé */}
                <div className="footer-note">
                    <p>© 2024 Casas. Todos os direitos reservados.</p>
                </div>
            </footer>
        </div>
    );
}
