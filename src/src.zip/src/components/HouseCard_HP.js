import React from "react";

export function HouseCard_HP(props) {
    return (
        <div className="house_card_hp">
            <div className="house_img" style={{ backgroundImage: `url(../imagens/${props.id}.jpg)` }}>
            </div>
            <div className="house_title">
                <h3>{props.title}</h3>
                <h4>{props.price}€</h4>
            </div>
            <div className="house_location">
                <img src="/icons/location.png" alt="Location" className="icon" />
                <p>{props.address}</p>
            </div>
            <div className="house_description">
                <div className="item">
                    <img src="/icons/bed.png" alt="beds" className="icon" />
                    <span className="item_text">{props.beds}</span>
                </div>
                <div className="item">
                    <img src="/icons/bath.png" alt="baths" className="icon" />
                    <span className="item_text">{props.baths}</span>
                </div>
            </div>
        </div>
    );
}



