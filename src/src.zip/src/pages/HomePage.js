import React, { useEffect, useState } from "react";
import { Banner } from "../components/Banner";
import { HouseCard_HP } from "../components/HouseCard_HP";
import { Slider_ } from "../components/Slider";
import "./HomePage.css";

export function HomePage() {
  const [houses, setHouses] = useState([]);

  // Função para buscar as propriedades
  const getHouses = async () => {
    try {
        const response = await fetch("http://localhost:3000/houses?review_gte=4");
      // Filtra casas com ranking >= 4
        const data = await response.json();
        setHouses(data);
    } catch (error) {
      console.error("Error fetching houses:", error);
    }
  };

  useEffect(() => {
    getHouses();
  }, []); // O efeito será executado apenas uma vez, ao montar o componente

  return (
    <main className="main">
      <Banner /> 
      <section className="house_container_hp">
        <h2 className="Featured Properties">Featured Properties</h2>
        <Slider_>   
          {houses.map((house) => (
            <div key={house.id} className="slider_card">
              <HouseCard_HP {...house} context="home_card"/>
            </div>
          ))}
        </Slider_>
      </section>
    </main>
  );
}